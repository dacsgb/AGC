// ##########################################
// 
//   Author  -   Collin Thornton
//   Email   -   collin.thornton@okstate.edu
//   Alg     -   Loss-of-Signal (LOS) SOURCE
//   Date    -   06-04-2020
//
//   class LOS
//      LOS(ros::NodeHandle &nh, unsigned int PERIOD, char* los_srv_server_name, char* los_srv_client_name)
//      void update()
//      
//  *NOTES*
//   -Only one instance of this class should be initialized
//   -Pass the instance by reference to other classes as necessary
//
// ##########################################   



#include "los.hpp"

namespace low_level {
    namespace nucleo {

        // Implementaton of LOS class
        LOS::LOS(ros::NodeHandle &nh, int PERIOD, char* los_srv_server_name, char* los_srv_client_name) : nucleo_server(los_srv_server_name, &LOS::nucleo_cb, this), 
          jetson_server(los_srv_client_name) {
            nucleo_state.status.data    = status::status_msg::HEALTHY;
            jetson_state.status.data    = status::status_msg::CONNECTING;
            prev_jstate.status.data     = status::status_msg::CONNECTING;
            prev_nstate.status.data     = status::status_msg::CONNECTING;

            handle_connecting();

            _nh = &nh;
            this->PERIOD = PERIOD;

            _nh->advertiseService(nucleo_server);
            _nh->serviceClient(jetson_server);

            los_timeout.attach_us(callback(this, &LOS::timeout_callback), 3*PERIOD);
        }
        int LOS::update() {
            if(!_nh->connected()) { 
                nucleo_state.status.data    = status::status_msg::DISCONNECTED;
                jetson_state.status.data    = status::status_msg::DISCONNECTED; 
                prev_jstate.status.data     = status::status_msg::DISCONNECTED;
            }

            status::status_srvRequest   jetson_req;
            status::status_srvResponse  jetson_resp;

            los_timeout.attach_us(callback(this, &LOS::timeout_callback), 3*PERIOD);

            // Call all services in this block
            //! SERVICE CALLS MUST HAVE A TIMEOUT GUARD
            jetson_server.call(jetson_req, jetson_resp);
            //
            los_timeout.detach();

            jetson_state.status = jetson_resp.status;


            switch(nucleo_state.status.data) {
                case status::status_msg::FATAL:
                    if(prev_nstate.status.data != nucleo_state.status.data) handle_nucleo_fatal();
                    return status::status_msg::FATAL;
                case status::status_msg::UNSTABLE:
                    handle_nucleo_unstable();       // Guard intentionally removed
                    return status::status_msg::UNSTABLE;
                case status::status_msg::HEALTHY:
                    if(prev_nstate.status.data != nucleo_state.status.data) handle_nucleo_healthy();
                    break;
                case status::status_msg::DISCONNECTED:
                    if(prev_nstate.status.data != nucleo_state.status.data) handle_disconnect();
                    return status::status_msg::DISCONNECTED;
            }

            switch(jetson_state.status.data) {
                case status::status_msg::FATAL:
                    if(prev_jstate.status.data != jetson_state.status.data) handle_jetson_fatal();
                    return status::status_msg::FATAL;
                case status::status_msg::HEALTHY:
                    if(prev_jstate.status.data != jetson_state.status.data) handle_jetson_healthy();
                    break;
                case status::status_msg::UNSTABLE:
                    if(prev_jstate.status.data != jetson_state.status.data) handle_jetson_unstable();
                    return status::status_msg::UNSTABLE;
                default:
                    _nh->logwarn("NUCLEO::LOS - UNKNOWN CONNECTION STATE FROM JETSON");
                    break;
            }

            return jetson_state.status.data;
        }
        void LOS::handle_jetson_healthy() {
            prev_jstate = jetson_state;
            if(nucleo_state.status.data == status::status_msg::HEALTHY) all_leds_off();
            green_led_blink_slow();
        }
        void LOS::handle_jetson_unstable() {
            prev_jstate = jetson_state;
            (nucleo_state.status.data == status::status_msg::UNSTABLE) ? yellow_led_on() : yellow_led_blink_slow();
        }
        void LOS::handle_jetson_fatal() {       //! STOP EVERYTHING
            prev_jstate = jetson_state;
            only_red_led_on();
        }
        void LOS::handle_nucleo_healthy() {
            prev_nstate = nucleo_state;
            if(jetson_state.status.data == status::status_msg::HEALTHY) {
                yellow_led_off();
                red_led_off();
                green_led_blink_slow();
            }
        }
        void LOS::handle_nucleo_unstable() {
            prev_nstate = nucleo_state;
            if(++unstable_count == 20) nucleo_state.status.data = status::status_msg::HEALTHY;
            if(unstable_count == 1) (jetson_state.status.data == status::status_msg::UNSTABLE) ? yellow_led_on() : yellow_led_blink_fast();
        }
        void LOS::handle_nucleo_fatal() {       //! STOP EVERYTHING
            prev_nstate = nucleo_state;
            all_leds_off();
            red_led_on();
            yellow_led_on();
        }
        void LOS::handle_connecting() {
            prev_nstate = nucleo_state;
            all_leds_off();
            green_led_blink_fast();
        }
        void LOS::handle_disconnect() {         //! STOP EVERYTHING
            prev_nstate = nucleo_state;
            all_leds_off();
            red_led_blink_fast();
        }
        void LOS::set_nucleo_fatal() {
            nucleo_state.status.data = status::status_msg::FATAL;
        }
        void LOS::set_nucleo_healthy() {
            if(unstable_count >= 20) nucleo_state.status.data = status::status_msg::HEALTHY;
        }
        void LOS::set_nucleo_unstable() {
            nucleo_state.status.data = status::status_msg::UNSTABLE;
            unstable_count = 0;
        }

        // Callback for LOS timeout
        void LOS::timeout_callback() {
            nucleo_state.status.data = status::status_msg::DISCONNECTED;
            handle_disconnect();
        }
        // Callback for nucleo service server
        void LOS::nucleo_cb(const status::status_srvRequest &req, status::status_srvResponse &resp){
            resp.status = nucleo_state.status;
        }        
    }
}
